import React, { useState } from 'react';
import MonacoEditor from '@monaco-editor/react';
import parser from './stack'; // Importa o parser gerado pelo PEG.js
import './Stack.css'; // Estilos para a pilha visual

function App() {
  const [code, setCode] = useState('criar Pilha');
  const [stack, setStack] = useState([]);
  const [output, setOutput] = useState('');

  const handleEditorChange = (value) => {
    setCode(value);
  };

  const runCode = () => {
    try {
      const commands = parser.parse(code);
      let newStack = [...stack];
      commands.forEach((command) => {
        if (command.type === "CREATE_STACK") {
          newStack = []; // Cria uma nova pilha
        } else if (command.type === "PUSH") {
          newStack.push(command.value); // Adiciona item à pilha
        }
      });
      setStack(newStack);
      setOutput("Comandos executados com sucesso!");
    } catch (error) {
      setOutput(`Erro: ${error.message}`);
    }
  };

  return (
    <div style={{ display: 'flex', height: '100vh' }}>
      {/* Editor de código */}
      <div style={{ flex: 1, borderRight: '1px solid #ccc', padding: '1rem' }}>
        <h2>Editor de Comandos</h2>
        <MonacoEditor
          height="80%"
          defaultLanguage="plaintext"
          value={code}
          onChange={handleEditorChange}
          theme="vs-dark"
        />
        <button onClick={runCode} style={{ marginTop: '1rem', padding: '0.5rem', fontSize: '1rem' }}>
          Executar Código
        </button>
      </div>

      {/* Visualização da Pilha */}
      <div style={{ flex: 1, padding: '1rem' }}>
        <h2>Visualização da Pilha</h2>
        <div className="stack-container">
          {stack.map((item, index) => (
            <div key={index} className="stack-item">{item}</div>
          ))}
        </div>
        <h3>Saída:</h3>
        <pre>{output}</pre>
      </div>
    </div>
  );
}

export default App;
